import { Page } from '@playwright/test';
import PageFactory from '../factory/PageFactory';
import { gotoURL, wait } from '../../com.reusable/utils/action-utils';

export async function register(page?: Page) {
  const registerOR = PageFactory.getRegisterOR(page);
  await gotoURL('https://ecommerce-playground.lambdatest.io/index.php?route=account/register');
  await registerOR.firstName.fill('John');
  await registerOR.lastName.fill('Doe');
  // use shared wait helper instead of accessing page on the OR (may be undefined)
  await wait(15000);
}

// export async function verifyInstagaramPageURL() {
//   await expectPageToHaveURL(new RegExp('https://www.instagram.com/'));
// }

