import { Page } from '@playwright/test';
import { RegisterOR } from '../object-repository/RegisterOR';
import { getPage } from '../../com.reusable/utils/page-utils';

export class PageFactory {
  static getRegisterOR(page?: Page): RegisterOR {
    const pageInstance = page ?? getPage();
    return new RegisterOR(pageInstance as Page);
  }
}

export default PageFactory;
