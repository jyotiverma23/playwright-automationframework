// import { click, clickAndNavigate, gotoURL } from '../../com.reusable/utils/action-utils';
// import { expectPageToHaveURL } from '../../com.reusable/utils/assert-utils';
import { getLocator, getLocatorByTestId } from '../../com.reusable/utils/locator-utils';
import { Page, Locator } from '@playwright/test';
import { getPage } from '../../com.reusable/utils/page-utils';

export class RegisterOR {
  public page: Page;

  constructor(page?: Page) {
    // prefer explicit page, fallback to global page
    this.page = (page ?? getPage()) as Page;
  }

  get lastName(): Locator {
    // Try common selectors: id, name, placeholder, or data-testid
    return getLocator(`#input-lastname, input[name='lastname'], input[id*='lastname'], [placeholder='Last Name'], [data-testid='input-lastname']`);
  }

  get firstName(): Locator {
    return getLocator(`#input-firstname, input[name='firstname'], input[id*='firstname'], [placeholder='First Name'], [data-testid='input-firstname']`);
  }
}

// export const instagramLink = getLocatorByText('Instagram', { exact: true });
// export const privacyPolicyLink = () => getLocatorByText('Privacy Policy');
// export const metaQuestLink = () => getLocatorByText('Meta Quest');