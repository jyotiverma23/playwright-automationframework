import { test } from '../src/com.reusable/setup/page-setup';
import { expect } from '@playwright/test';
import { register } from '../src/com.pom/page-functionality/RegisterPage';

test('regestration process', async ({ page }) => {
  await register(page);
  // Expect a title "to contain" a substring.
});

test('get started link', async ({ page }) => {
  await page.goto('https://playwright.dev/');

  // Click the get started link.
  await page.getByRole('link', { name: 'Get started' }).click();

  // Expects page to have a heading with the name of Installation.
  await expect(page.getByRole('heading', { name: 'Installation' })).toBeVisible();
});
